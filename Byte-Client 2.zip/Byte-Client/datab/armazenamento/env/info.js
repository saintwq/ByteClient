
const configurações = {
  prefixo: ".",
  nomeBot: "Byte  Client", 
  nomeDono: "Shotziin", 
  numeroDono: "557196825414"
}

global.configurações = configurações 

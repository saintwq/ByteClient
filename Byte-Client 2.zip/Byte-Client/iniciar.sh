while : 
do

gray="\033[1;30m"

echo "${gray}Inciando o Client"
sleep 4
    clear
    node .
    sleep 2

done
